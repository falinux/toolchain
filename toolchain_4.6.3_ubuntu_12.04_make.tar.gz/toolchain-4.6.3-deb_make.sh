#!/bin/sh

dpkg-deb -x ./deb/binutils-arm-linux-gnueabihf_2.22-6ubuntu1cross1.82_i386.deb toolchain
dpkg-deb -x ./deb/cpp-4.6-arm-linux-gnueabihf_4.6.3-1ubuntu5cross1.63_i386.deb toolchain
dpkg-deb -x ./deb/g++-4.6-arm-linux-gnueabihf_4.6.3-1ubuntu5cross1.63_i386.deb toolchain
dpkg-deb -x ./deb/gcc-4.6-arm-linux-gnueabihf-base_4.6.3-1ubuntu5cross1.63_all.deb toolchain
dpkg-deb -x ./deb/gcc-4.6-arm-linux-gnueabihf_4.6.3-1ubuntu5cross1.63_i386.deb toolchain
dpkg-deb -x ./deb/libc6-dev-armhf-cross_2.15-0ubuntu9cross1.82_all.deb toolchain
dpkg-deb -x ./deb/libgcc1-armhf-cross_4.6.3-1ubuntu5cross1.82_all.deb toolchain
dpkg-deb -x ./deb/libgomp1-armhf-cross_4.6.3-1ubuntu5cross1.63_all.deb toolchain
dpkg-deb -x ./deb/libmudflap0-4.6-dev-armhf-cross_4.6.3-1ubuntu5cross1.63_all.deb toolchain
dpkg-deb -x ./deb/libstdc++6-4.6-dev-armhf-cross_4.6.3-1ubuntu5cross1.63_all.deb toolchain
dpkg-deb -x ./deb/libc6-armhf-cross_2.15-0ubuntu9cross1.82_all.deb toolchain
dpkg-deb -x ./deb/libgcc1-armhf-cross_4.6.3-1ubuntu5cross1.82_all.deb toolchain
dpkg-deb -x ./deb/libc6-dev-armhf-cross_2.15-0ubuntu9cross1.82_all.deb toolchain
dpkg-deb -x ./deb/libc6-dbg-armhf-cross_2.15-0ubuntu9cross1.82_all.deb toolchain

rm -rf toolchain/usr/arm-linux-gnueabi

mkdir toolchain/usr/include
ln -s /usr/include/i386-linux-gnu/asm toolchain/usr/include/asm

cd toolchain/usr/bin
ln -s arm-linux-gnueabihf-gcc-4.6 arm-linux-gnueabihf-gcc
ln -s arm-linux-gnueabihf-cpp-4.6 arm-linux-gnueabihf-cpp
ln -s arm-linux-gnueabihf-g++-4.6 arm-linux-gnueabihf-g++ 
ln -s arm-linux-gnueabihf-g++-4.6 arm-linux-gnueabihf-c++ 
rm -rf arm-linux-gnueabihf-ld
ln -s arm-linux-gnueabihf-ld.bfd arm-linux-gnueabihf-ld 

cd ../../

tar -zcf ../arm-linux-gnueabihf-4.6.3.tar.gz usr
