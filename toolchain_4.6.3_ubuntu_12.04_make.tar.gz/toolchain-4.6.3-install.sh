#!/bin/sh

sudo cp -a arm-linux-gnueabihf-4.6.3.tar.gz /
cd /
sudo tar -zxvf arm-linux-gnueabihf-4.6.3.tar.gz
